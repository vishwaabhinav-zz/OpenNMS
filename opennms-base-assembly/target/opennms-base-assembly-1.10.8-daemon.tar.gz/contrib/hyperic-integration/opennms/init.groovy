plugin.name = "opennms"
plugin.description = "OpenNMS Exporter"
plugin.version  = '0.1'
plugin.apiMajor = 0
plugin.apiMinor = 1

// Enable if you want to dump the translated scripts to stdout
plugin.dumpScripts = false
