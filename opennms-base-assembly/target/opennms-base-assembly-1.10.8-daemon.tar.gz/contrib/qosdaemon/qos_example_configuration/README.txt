Instructions for use

tested with opennms-1.3.2-SNAPSHOT Revision 4999

These scripts and configurations get the Qos and Qosrx interface working on 
OpenNMS 1.3.2

The following script should be run as root i.e.
sudo sh opennms_1_3_2_example_deploy_1dot0.sh

This will deploy code and example files to OpenNMS, Tomcat55 and JBOSS
to get the fault management interface working. 

The script is written to work with Fedora Core 4
Check the script to ensure it deploys to the correct locations for your 
distribution.

See /doc folder for description
