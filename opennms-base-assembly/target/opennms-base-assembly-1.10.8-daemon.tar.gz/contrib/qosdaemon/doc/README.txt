 This folder contains documentation for the qosdaemon. Documentation is provided
 as PDF and as OpenOffice format documents.
